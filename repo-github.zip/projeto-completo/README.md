# Sistema real (servidor Node.js)

Requer Node.js 18 ou mais novo. Não há nada para instalar.

    PAINEL_SENHA="uma-senha-forte" NOME_LOCAL="Nome do bar" LOJA_NOME="Trama Moda" node server.js

Windows PowerShell:

    $env:PAINEL_SENHA="uma-senha-forte"; $env:NOME_LOCAL="Nome do bar"; $env:LOJA_NOME="Trama Moda"; node server.js

- Loja: http://localhost:3000/
- QR Code da cabine 3: http://localhost:3000/ajuda?c=3
- Painel da equipe: http://localhost:3000/painel
- Gerador de QR Codes: http://localhost:3000/qr

As variáveis estão listadas em `env.exemplo`. A publicação na Render está descrita no README da raiz do repositório.
